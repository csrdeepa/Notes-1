<?php
/**
 * Plugin Name:  Post Grid with Ajax Filter Customized 
 * Plugin URI:   
 * Author:       Deepa
 * Author URI:   
 * Version: 	  0.0.1
 * Description:  Post Grid with Ajax Filter helps you filter your posts by category terms with Ajax. Infinite scroll function included.
 * License:      
 * License URI:  
 * Text Domain:  am_post_grid
 * Domain Path:  /lang
 */

/**
* Including Plugin file for security
* Include_once
*
* @since 1.0.0
*/
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// Defines
define('AM_POST_GRID_VERSION', '0.0.1');

/**
* Loading Text Domain
*/
add_action('plugins_loaded', 'am_post_grid_plugin_loaded_action', 10, 2);
function am_post_grid_plugin_loaded_action() {
	load_plugin_textdomain( 'am_post_grid', false, dirname( plugin_basename(__FILE__) ) . '/lang/' );
}


/**
 *	Admin Page
 */
//require_once( dirname( __FILE__ ) . '/inc/admin/admin-page.php' );


// Enqueue scripts
function asrafp_scripts(){

	// CSS File
	wp_enqueue_style( 'asrafp-styles', plugin_dir_url( __FILE__ ) . 'assets/css/post-grid-styles.css', null, AM_POST_GRID_VERSION );

	// JS File
	wp_register_script( 'asr_ajax_filter_post', plugin_dir_url( __FILE__ ) . 'assets/js/post-grid-scripts.js', array('jquery'), AM_POST_GRID_VERSION );
	wp_enqueue_script( 'asr_ajax_filter_post' );

	// Localization
	wp_localize_script( 'asr_ajax_filter_post', 'asr_ajax_params', array(
	        'asr_ajax_nonce' => wp_create_nonce( 'asr_ajax_nonce' ),
	        'asr_ajax_url' => admin_url( 'admin-ajax.php' ),
	    )
	);
}

add_action( 'wp_enqueue_scripts', 'asrafp_scripts' );

function ttdeepcdn_scripts(){

	//CSS File
	wp_enqueue_style( 'tts-bootstrapstyles', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css', null, '' );

	//JS File
	wp_register_script( 'ttsp_bootstrapscript','https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js', array('jquery'), '' );
	wp_enqueue_script( 'ttsp_bootstrapscript' );

	// Enque JS File footer
// 	wp_register_script( 'ttsp_jqminscript','https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js', array('jquery'), '', true );
// 	wp_enqueue_script( 'ttsp_jqminscript' );	
}
add_action( 'wp_enqueue_scripts', 'ttdeepcdn_scripts' );
function custom_post_type() {
    // Certificate programs
    $labels = array(
        'name'                => _x( 'Certificate programs', 'Post Type General Name' ),
        'singular_name'       => _x( 'Certificate program', 'Post Type Singular Name' ),
        'menu_name'           => __( 'Certificate programs' ),
        'parent_item_colon'   => __( 'Parent Certificate program' ),
        'all_items'           => __( 'All Certificate programs' ),
        'view_item'           => __( 'View Certificate program' ),
        'add_new_item'        => __( 'Add New Certificate program' ),
        'add_new'             => __( 'Add New' ),
        'edit_item'           => __( 'Edit Certificate program' ),
        'update_item'         => __( 'Update Certificate program' ),
        'search_items'        => __( 'Search Certificate program' ),
        'not_found'           => __( 'Not Found' ),
        'not_found_in_trash'  => __( 'Not found in Trash' ),
    );
    $args = array(
        'label'               => __( 'certificate_programs' ),
        'description'         => __( 'Certificate program news and reviews' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,
// 		'taxonomies'          => array( 'category' ),
    );
    register_post_type( 'certificate_programs', $args );

	    register_taxonomy( 'cp_category', array( 'certificate_programs' ), array(
        'hierarchical' => true,
        'label' => __( 'Category' ),
        'labels' => array( // Labels customizadas
        'name' => _x( 'Categories', 'taxonomy general name' ),
        'singular_name' => _x( 'Category', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search categories ' ),
        'all_items' => __( 'All categories' ),
        'parent_item' => __( 'Parent Category' ),
        'parent_item_colon' => __( 'Parent Category:' ),
        'edit_item' => __( 'Edit Category' ),
        'update_item' => __( 'Update Category' ),
        'add_new_item' => __( 'Add new Category' ),
        'new_item_name' => __( 'Name of Category' ),
        'menu_name' => __( 'Category' ),
        ),
        'show_ui' => true,
        'show_in_tag_cloud' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'certificate_programs/categories',
            'with_front' => false,
        ),)
    );
 
		register_taxonomy( 'cp_sponsors', array( 'certificate_programs' ), array(
        'hierarchical' => true,
        'label' => __( 'Sponsors' ),
        'labels' => array( // Labels customizadas
        'name' => _x( 'Sponsors', 'taxonomy general name' ),
        'singular_name' => _x( 'Sponsors', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search Sponsors ' ),
        'all_items' => __( 'All Sponsors' ),
        'parent_item' => __( 'Parent Sponsors' ),
        'parent_item_colon' => __( 'Parent Sponsors:' ),
        'edit_item' => __( 'Edit Sponsors' ),
        'update_item' => __( 'Update Sponsors' ),
        'add_new_item' => __( 'Add new Sponsors' ),
        'new_item_name' => __( 'Name of Sponsors' ),
        'menu_name' => __( 'Sponsors' ),
        ),
        'show_ui' => true,
        'show_in_tag_cloud' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'certificate_programs/sponsors',
            'with_front' => false,
        ),)
    );
		register_taxonomy( 'cp_types', array( 'certificate_programs' ), array(
        'hierarchical' => true,
        'label' => __( 'Type' ),
        'labels' => array( // Labels customizadas
        'name' => _x( 'Type', 'taxonomy general name' ),
        'singular_name' => _x( 'Type', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search Type ' ),
        'all_items' => __( 'All Type' ),
        'parent_item' => __( 'Parent Type' ),
        'parent_item_colon' => __( 'Parent Type:' ),
        'edit_item' => __( 'Edit Type' ),
        'update_item' => __( 'Update Type' ),
        'add_new_item' => __( 'Add new Type' ),
        'new_item_name' => __( 'Name of Type' ),
        'menu_name' => __( 'Type' ),
        ),
        'show_ui' => true,
        'show_in_tag_cloud' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'certificate_programs/types',
            'with_front' => false,
        ),)
    );
    register_taxonomy_for_object_type( 'tags', 'certificate_programs' );
}
add_action( 'init', 'custom_post_type', 0 );

//shortcode function
function am_post_grid_shortcode_mapper( $atts, $content = null ) {

	// Posts per pages.
	$posts_per_page = ( get_option( 'posts_per_page', true ) ) ? get_option( 'posts_per_page', true ) : 9;

	// Default attributes
	$shortcode_atts = shortcode_atts(
            array(
                'show_filter' 		=> "yes",
                'btn_all' 			=> "yes",
                'initial' 			=> "-1",
                'layout' 			=> '1',
                'post_type' 		=> 'post',
                'posts_per_page' 	=> $posts_per_page,
                'cat' 				=> '',
                'terms' 			=> '',
                'paginate' 			=> 'no',
                'hide_empty' 		=> 'true',
                'orderby' 			=> 'menu_order date', //Display posts sorted by ‘menu_order’ with a fallback to post ‘date’
    			'order'   			=> 'DESC',
    			'pagination_type'   => '',
    			'infinite_scroll'   => '',
    			'animation'  		=> '',
            ),
            $atts
        );

    // Params extraction
    extract($shortcode_atts);

	ob_start();
	$show_filter = isset($atts["show_filter"] ) ? $atts["show_filter"] : 'no';
	$post_type = isset($atts["post_type"] ) ? $atts["post_type"] : 'post';
	$layout = isset($atts["layout"] ) ? $atts["layout"] : 1;	
	// Texonomy arguments
	$taxonomy = 'category';
	$args = array(
		'hide_empty' => $hide_empty,
	    'taxonomy' => $taxonomy,
	    'include' => $terms ? $terms : $cat,
	);

	// Get category terms
	$terms = get_terms($args); ?>
	<div class="am_ajax_post_grid_wrap" data-pagination_type="<?php echo esc_attr($pagination_type); ?>" data-am_ajax_post_grid='<?php echo json_encode($shortcode_atts);?>'>

		<?php if ( $show_filter == "yes" && $terms && !is_wp_error( $terms ) ){ ?>
			<div class="asr-filter-div" data-layout="<?php echo $layout; ?>">
				<ul>
					<?php if($btn_all != "no"): ?>
						<li class="asr_texonomy" data_id="-1"><?php echo esc_html('All','am_post_grid'); ?></li>
					<?php endif; ?>
					<?php foreach( $terms as $term ) { ?>
						<li class="asr_texonomy" data_id="<?php echo $term->term_id; ?>"><?php echo $term->name; ?></li>
					<?php } ?>
				</ul>
			</div>
		
		<?php if ( $layout == 2 ){ ?>
		
		<div class="taxonamies" style="display:none">
			<?php
			$taxonomies = get_object_taxonomies( $post_type, 'objects' );

			foreach( $taxonomies as $taxonomy ){
				echo $taxonomy->name;

				$terms = get_terms(array(
					'taxonomy' => $taxonomy->name,
					'hide_empty' => false,
				)); 
			?> <ul class="<?php echo $taxonomy->name ?>"> <?php
				foreach( $terms as $term ){
					echo "<li>{$term->name}</li>";
				}
			?> </ul> <?php
			}																   
			?>
		</div>
		
<!--#test filter-->
	<div class="ms_filter">
		<div class="ms_fil_left">
			<div class="filt_input">
				<i class="fa fa-search"></i>
				<input type="text" class="form-control sm_filt" placeholder="Search by title" style="height: 40px;width: 250px;">
			</div>
			<div class="drop_rel" >

				<div class="dropdown mx_dropdown" style="height: 100%;">
					<button class="btn btn-secondary mx_button" type="button" style="height: 40px; border-radius: 5px; font-size: 1rem;">
						Filter by
					</button>


					<div class="filter-show">
						<div class="tab-fil" style="height: 350px;">
							<ul class="nav nav-tabs flex-column kn_tabs" role="tablist" style=" list-style: none;">
								<li class="nav-item">
									<a class="nav-link" data-bs-toggle="tab" href="#home">Date</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" data-bs-toggle="tab" href="#menu1">Type</a>
								</li>
								<li class="nav-item">
									<a class="nav-link active" data-bs-toggle="tab" href="#menu2">Category</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" data-bs-toggle="tab" href="#menu3">Sponsors</a>
								</li>
								<li class="nav-item no_border">
									<a class="nav-link" data-bs-toggle="tab" href="#menu4">Month</a>
								</li>
							</ul>
							<div class="tab-content mils">
								<div id="home" class="container tab-pane active">
									<div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												All
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Host-School
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Leadership
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Medicine
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Communication
											</div>
										</div>
									</div>
								
								</div>
								<div id="menu1" class="container tab-pane fade">
									<div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												All
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Host-School
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Leadership
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Medicine
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Communication
											</div>
										</div>
									</div>

								</div>
								<div id="menu2" class="container tab-pane fade">
									<div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												All
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Host-School
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Leadership
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Medicine
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Communication
											</div>
										</div>
									</div>
								</div>
								<div id="menu4" class="container tab-pane fade">
									<div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												All
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Host-School
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Leadership
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Medicine
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Communication
											</div>
										</div>
									</div>
								</div>
								<div id="menu5" class="container tab-pane fade">
									<div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												All
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Host-School
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Leadership
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox" checked>
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Medicine
											</div>
										</div>
										<div class="ms_fill">
											<div class="ms_fill_icon">
												<label class="switch">
													<input type="checkbox">
													<span class="slider round"></span>
												  </label>
											</div>
											<div class="ms_fill_text">
												Communication
											</div>
										</div>
									</div>
								</div>

							</div>


						</div>
						<div class="button_box">
							<div><button type="button" class="btn-apply">Apply <i
										class="fa fa-chevron-right"></i></button></div>
							<div><button type="button" class="btn-cancel" id="ttsbtn-cancel">Cancel</button></div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<div class="ms_fil_right">

			<div class="filt_right_i " id="list_view">
				<i class="fa fa-list">list</i>
			</div>
			<div class="filt_right_i orange" id="grid_view">
				<i class="fas fa-border-all">grid</i>
			</div>
			<div>
				<select class=" sm_select" style="height: 40px;">
					<option value="0">Sort by Date</option>
					<option value="1">Weekly</option>
				</select>
			</div>
		</div>
	</div>		
<!--@test filter-->
		 <?php } ?>
	    <?php } ?>

	    <div class="asr-ajax-container">
		    <div class="asr-loader">
		    	<div class="lds-dual-ring"></div>
		    </div>
		    <div class="asrafp-filter-result"></div>
	    </div>
    </div>

	<?php return ob_get_clean();
}
add_shortcode('asr_ajax','am_post_grid_shortcode_mapper');
add_shortcode('am_post_grid','am_post_grid_shortcode_mapper');

// Load Posts Ajax actions
add_action('wp_ajax_asr_filter_posts', 'am_post_grid_load_posts_ajax_functions');
add_action('wp_ajax_nopriv_asr_filter_posts', 'am_post_grid_load_posts_ajax_functions');

// Load Posts Ajax function
function am_post_grid_load_posts_ajax_functions(){
	// Verify nonce
  	if( !isset( $_POST['asr_ajax_nonce'] ) || !wp_verify_nonce( $_POST['asr_ajax_nonce'], 'asr_ajax_nonce' ) )
    die('Permission denied');

	$term_ID = isset( $_POST['term_ID'] ) ? sanitize_text_field( intval($_POST['term_ID']) ) : null;
	$layout = isset( $_POST['layout'] ) ? intval( sanitize_text_field( $_POST['layout'] ) ) : 1;
	$pagination_type = isset( $_POST['pagination_type'] ) ? sanitize_text_field( $_POST['pagination_type'] ) : null;

	// Pagination
	if( $_POST['paged'] ) {
		$dataPaged = intval($_POST['paged']);
	} else {
		$dataPaged = get_query_var('paged') ? get_query_var('paged') : 1;
	}

	$jsonData = json_decode( str_replace('\\', '', $_POST['jsonData']), true );

	// Add infinite_scroll to button
	$infinite_scroll_class = isset( $jsonData['infinite_scroll'] ) && $jsonData['infinite_scroll'] == "true" ? ' infinite_scroll ' : '';

	// Set animation class
	$has_animation_class = isset( $jsonData['animation'] ) && $jsonData['animation'] == "true" ? ' am_has_animation ' : '';

	$data = array(
		'post_type' => 'post',
		'post_status' => 'publish',
		'paged' => $dataPaged,
	);

	// If json data found
	if( $jsonData ){
		if( $jsonData['posts_per_page'] ){
			$data['posts_per_page'] = intval( $jsonData['posts_per_page'] );
		}

		if( $jsonData['orderby'] ){
			$data['orderby'] = sanitize_text_field( $jsonData['orderby'] );
		}

		if( $jsonData['order'] ){
			$data['order'] = sanitize_text_field( $jsonData['order'] );
		}
	}

	// Bind to Category Terms
	if( $term_ID == -1 ){
		if ( isset( $jsonData['cat'] ) && !empty( $jsonData['cat'] ) ) {
			$term_ID = explode(',', $jsonData['cat']);
		} elseif ( isset( $jsonData['terms'] ) && !empty( $jsonData['terms'] ) ) {
			$term_ID = explode(',', $jsonData['terms']);
		} else {
			$term_ID =  null;
		}
		
	}

	// Check if set terms 
	if( $term_ID ){
		$data['tax_query'] = array(
			array(
				'taxonomy' => 'category',
				'field' => 'term_id',
				'terms' => $term_ID,
			)
		);
	}

	//post query
	$query = new WP_Query($data);
	ob_start();

	// Wrap with a div when infinity load
	echo ( $pagination_type == 'load_more' ) ? '<div class="am-postgrid-wrapper">' : '';

	// Start posts query
	if( $query->have_posts() ): ?>




		<?php if($layout == 1){ ?>
		<div class="<?php echo esc_attr( "am_post_grid am__col-3 am_layout_{$layout} {$has_animation_class} " ); ?>">
		
			<?php while( $query->have_posts()): $query->the_post(); ?>
			<div class="am_grid_col">
				<div class="am_single_grid">
					<div class="am_thumb">
						<?php the_post_thumbnail('full'); ?>
					</div>
					<div class="am_cont">
						<a href="<?php echo get_the_permalink(); ?>"><h2 class="am__title"><?php echo get_the_title(); ?></h2></a>
						<div class="am__excerpt">
							<?php echo wp_trim_words( get_the_excerpt(), 15, null ); ?>
						</div>
						<a href="<?php echo get_the_permalink(); ?>" class="am__readmore"><?php echo esc_html__('Read More','am_post_grid');?></a>
					</div>
				</div>
			</div>
		<?php endwhile; ?>	
					</div>
			<?php } else if( $layout == 2 ){ ?>

<div class="<?php echo esc_attr( "tts_post_grid tts_container tts_layout_{$layout} {$has_animation_class} " ); ?>">
	<div id="grid">
		<div class="row">
			<?php while( $query->have_posts()): $query->the_post(); ?>	
			<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
				<div class="strip">
					<figure>
						<?php the_post_thumbnail('full'); ?>
						<a href="<?php echo get_the_permalink(); ?>" class="strip_info">
							<small><img src="img/Rectangle-209-1.png"></small>
							<div class="item_title">
								<div class="leader_sp">#<?php
											$terms = get_the_terms( $post->ID , $jsonData['taxonomy'] );
											foreach ( $terms as $term ) {
											echo $term->name;
											}
											?></div>
								<h3><?php echo get_the_title(); ?></h3>
								<small>
									<p class="leader_sp2"><?php echo wp_trim_words( get_the_excerpt(), 15, null ); ?></p>
								</small>
								<div class="leader_sp3">
									<div class="sp3">
										<div class="leader_sp4">Starts on</div>
										<div class="leader_sp5">10 Jun, 2022</div>
									</div>
									<div class="sp4">
										<div class="leader_sp4">Duration</div>
										<div class="leader_sp5">2 Weeks</div>
									</div>
								</div>
								<div class="leader_sp6">
<!-- 									<i class="fa fa-arrow-right"></i> -->
									<img src="/wp-content/uploads/2022/04/right-arrow.svg" alt="arrow" style="width:25px" style=" padding-right: 5px;">
								</div>
	
							</div>
						</a>
					</figure>
				</div>
			</div>
			

		<?php endwhile; ?>
		</div>
	</div>
		</div>
			<?php } ?>




		<div class="am_posts_navigation">
		<?php
			$big = 999999999; // need an unlikely integer
			$dataNext = $dataPaged+1;

			$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

			$paginate_links = paginate_links( array(
			    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			    'format' => '?paged=%#%',
			    'current' => max( 1, $dataPaged ),
			    'prev_next' => false,
			    'mid_size' => 2,
			    'total' => $query->max_num_pages
			) );

			// Load more button
			if( $pagination_type == 'load_more' ){

				if( $paginate_links && $dataPaged < $query->max_num_pages ){
					echo "<button type='button' data-paged='{$dataPaged}' data-next='{$dataNext}' class='{$infinite_scroll_class} am-post-grid-load-more'>".esc_html__( 'Load More', 'am_post_grid' )."</button>";
				}

			} else {

				// Paginate links
				echo "<div id='am_posts_navigation_init'>{$paginate_links}</div>";
			}

		?>
		</div>

		<?php
	else:
		esc_html_e('No Posts Found','am_post_grid');
	endif;
	wp_reset_query();

	// Wrap close when infinity load
	echo ( $pagination_type == 'load_more' ) ? '</div>' : '';

	// Echo the results
	echo ob_get_clean();
	die();
}



/**
 * Add plugin action links.
 *
 * @since 1.0.0
 * @version 4.0.0
 */
function am_ajax_post_grid_plugin_action_links( $links ) {
	$plugin_links = array(
		'<a href="'.admin_url( 'admin.php?page=ajax-post-grid' ).'">' . esc_html__( 'Options', 'am_post_grid' ) . '</a>',
	);
	return array_merge( $plugin_links, $links );
}
//add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'am_ajax_post_grid_plugin_action_links' );


